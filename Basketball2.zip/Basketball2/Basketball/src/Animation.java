import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.*;
import java.net.*;
import javax.imageio.ImageIO;
import javax.swing.*;
/**
 * Testing class for animation
 * May use in future in place of running gifs
 * @author annabelng
 *
 */
public class Animation {

	private int x,y;
    private int currentImage = 0;
    private JLabel animationDisplayLabel = new JLabel();
    private Timer animationTimer;
    
    private String suffix = ".png";
    private String[] imageNames = {"runn1", "run2", "run3", "run4", "run5"};
    protected ImageIcon[] images = new ImageIcon[imageNames.length];

    public Animation() {
        for (int count = 0; count < images.length; count++) {
            try {
                //URL url = new URL(imageNames[count] + suffix);
                Image image = Toolkit.getDefaultToolkit().getImage(imageNames[count] + suffix);
                images[count] = new ImageIcon(image);
                x=500; 
                y=500;
            } catch (Exception ex) { // TODO! Better exception handling!
                ex.printStackTrace();
            }
        }
        startAnimation();
    }

    public void startAnimation() {
        ActionListener listener = new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                currentImage = (currentImage + 1) % images.length;
                animationDisplayLabel.setIcon(images[currentImage]);
            }
        };
        animationDisplayLabel.setIcon(images[0]);
        animationTimer = new Timer(200, listener);
        animationTimer.start();
    }

    public JComponent getAnimationComponent() {
        return animationDisplayLabel;
    }

    public static void main(String[] args) {
        Runnable r = new Runnable() {

            @Override
            public void run() {
                Animation fp = new Animation();

                JFrame f = new JFrame("car");
                f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                f.add(fp.getAnimationComponent());
                f.pack();
                f.setLocationByPlatform(true);

                f.setVisible(true);
            }
        };
        SwingUtilities.invokeLater(r);
    }
}

