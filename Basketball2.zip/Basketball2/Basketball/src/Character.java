
public abstract class Character {

	public abstract int getX();
	public abstract int getY();
	
}
