import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;
import java.awt.image.ImageObserver;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class Basketball extends JPanel{

	private int x,y;
	private int width, height;
	private Image img;
	private double vx, vy;
	
	int court_floor = 410;
	int court_wall = 1090;
	
	int radius = 50;//size
	
	double gravity =15;
	double energyloss = .65;
	double dt = .2;
	
	public Basketball(String filename) {
		//sets up board image to be drawn
		String src = new File("").getAbsolutePath() + "/src/";
		ImageIcon ast = new ImageIcon(src + filename);
		this.x = 565;
		this.y = 200;

		img = getImage(filename);
		
	}

	//method that allows board to be painted in the paint method
	// as opposed to simply being added into the frame
	public void paint(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.drawImage(img, x, y, this);
		
		
		
	}

	//getter for the image
	private Image getImage(String path) {

		img = Toolkit.getDefaultToolkit().getImage("basketball.jpg");
		return img;
	}
	
	public void update(){
		
	}
	
	public int getX(){
		return x;
	}
	
	public void setX(int x){
		this.x =x;
	}
	
	public int getY(){
		return y;
	}
	
	public void setY(int y){
		this.y =y;
	}
	
	public int getW(){
		return img.getWidth(null);
	}
	
	public int getH(){
		return img.getHeight(null);
	}
	
	
}