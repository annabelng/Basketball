/**
 * 
 * @author annabelng
 * Represents the hoop images 
 * Used the create the left and right hoops
 * 
 * Inherits from the imageObject class in order to get the
 * paint method, getters, and setters
 */
public class Hoops extends imageObject {
	
	/**
	 * Takes in the filename of the object so the 
	 * image and imageIcon can be initialized
	 * 
	 * Uses super to construct the image and initialize x,y,width,height values
	 * @param filename
	 * @param width
	 * @param height
	 * @param x
	 * @param y
	 */
	public Hoops(String filename, int width, int height, int x, int y) {
		//sets up board image to be drawn
		super(x,y,width,height,filename);
		
	}
}
