/**
 * Represents the basketball court
 * @author annabelng
 *
 * Inherits from the imageObject class in order to get the
 * paint method, getters, and setters
 */
public class Court extends imageObject{

	/**
	 * Extends imageObject parent class, which supers 
	 * the x,y coordinates, width, height, and links the 
	 * filename to the imageIcon
	 * 
	 * Child class also contains paint method and getters + setters
	 * @param filename
	 */
	public Court(String filename, int x, int y, int width, int height) {
		super(x,y,width,height,filename);
	}
	
}
