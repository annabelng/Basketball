/**
 * Class for the basketball object
 * 
 * Inherits drawing, getter, and setter methods from imageObject class
 * 
 * Contains methods to simulate physics
 * including drribling, bouncing, and shooting 
 * @author annabelNg, jaidenSmith, scottyKrysl
 *
 */
public class Basketball extends imageObject {

	//change in x and y variables
	private double dx = 10, dy = 10;
	
	//boundaries for the ball to bounce in
	private int court_floor = 350;
	private int court_wall = 1200;

	//size of the ball
	private int radius = 30;

	//different variables that affect physics of the ball
	double gravity = 15;
	double energyloss = .65;
	double dt = .2;

	/**
	 * supers the different params and sets up the image and basic variables
	 * @param filename
	 * @param x
	 * @param y
	 * @param width
	 * @param height
	 */
	public Basketball(String filename, int x, int y, int width, int height) {
		// sets up board image to be drawn
		super(x, y, width, height, filename);

	}

	/**
	 * Bounce method that checks if the ball is within boundaries and 
	 * changes the x and y variables accordingly
	 * 
	 * After all the checks have been executed, the x and y values are set
	 * using x and y setters
	 */
	public void bounce() {
		if (x + dx > court_wall) {
			x = court_wall;
			dx = -dx;
		} else if (x + dx < 100) {
			x = 100;
			dx = -dx;
		} else {
			x += dx;
		}

		if (y == court_floor - radius - 1) {
			dx *= .95;
			if (Math.abs(dx) < .1) {
				dx = 0;
			}
		}

		if (y > court_floor - radius - 1) {
			y = court_floor - radius - 21;
			// music.playSong();
			dy *= energyloss;
			dy = -dy;
		} else {
			dy += gravity * dt;
			y += dy * dt + .5 * gravity * dt * dt;
		}

		if (y == court_floor - radius - 21 && Math.abs(dy) < 5) {
			dy = 0;
			y = court_floor - radius - 21;
		}
		this.setX(x);
		this.setY(y);
	}

	/**
	 * If driver calls the dribble method,
	 * the ball's y changes according to the equation
	 * 
	 * It checks for the bottom or the point at which it should stop bouncing
	 * @param bottom
	 */
	public void dribbleLeft(int bottom) {
		this.setdy(10);
		if (y < (bottom + 10)) {
			y += dy * .9 + .8 * gravity * 4;
		} else {
			y -= 5;
		}

		this.setX(x);
		this.setY(y);
	}

	/**
	 * If driver calls the dribble method,
	 * the ball's y changes according to the equation
	 * 
	 * It checks for the bottom or the point at which it should stop bouncing
	 * 
	 * Adds a change in x to account for change in direction
	 * @param bottom
	 */
	public void dribbleRight(int bottom) {
		if (y < (bottom + 10)) {
			y += dy * .9 + .8 * gravity * 4;
		} else {
			y -= 5;
		}
		x += 25;
		this.setX(x);
		this.setY(y);
	}

	/**
	 * When ball is shot, the change in y remains at a constant of -55
	 * and dx depends on parameter
	 * 
	 * Simulates an arc
	 * @param dx
	 */
	public void shoot(int dx) {
		this.setdx(dx);
		this.setdy(-55);
	}

	/**
	 * setter for the changes in x
	 * @param d
	 */
	public void setdx(double d) {
		this.dx = d;
	}

	/**
	 * setter for the change in y
	 * @param d
	 */
	public void setdy(double d) {
		this.dy = d;
	}

}