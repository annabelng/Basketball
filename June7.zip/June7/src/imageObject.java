import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
/**
 * 
 * @author annabelng
 * Parent class for most of the objects containing images
 * Extends JPanel in order to have a paint method
 *
 */
public class imageObject extends JPanel{

	//private instance variables
	protected int x,y;
	private int width, height;
	private Image img;
	
	/**
	 * Constructor that takes in and instantiates all the different params
	 * Each param applies to every image object, regardless of whether its 
	 * the hoops or the ball
	 * 
	 * Also sets up the image so it can be painted onto screen
	 * @param x
	 * @param y
	 * @param width
	 * @param height
	 * @param filename
	 */
	public imageObject(int x, int y, int width, int height, String filename) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		
		//image set up
		String src = new File("").getAbsolutePath() + "/src/";
		ImageIcon ast = new ImageIcon(src + filename);
		img = getImg(filename);
	}
	
	/**
	 * Paint method that allows the image to be manipulated across screen
	 * and be drawn and updated
	 */
	public void paint(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.drawImage(img, x, y, this);
	}
	
	/**
	 * Getter for x variable
	 */
	public int getX() {
		return x;
	}

	/**
	 * Setter for x
	 * @param x
	 */
	public void setX(int x) {
		this.x = x;
	}
	
	/**
	 * Getter for y variable
	 */
	public int getY() {
		return y;
	}

	/**
	 * Setter for y
	 * @param y
	 */
	public void setY(int y) {
		this.y = y;
	}

	/**
	 * Getter for width
	 * Useful when creating rectangles to check for intersection
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * Setter for width
	 * @param width
	 */
	public void setWidth(int width) {
		this.width = width;
	}

	/**
	 * Getter for height
	 * Also useful for setting up rectangles
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * Setter for height
	 * @param height
	 */
	public void setHeight(int height) {
		this.height = height;
	}

	/**
	 * Getter for img
	 * Protected method so it is a bit more private than the other methods
	 * but still easily accessible by the different child classes
	 * @param path
	 * @return
	 */
	protected Image getImg(String path) {

		img = Toolkit.getDefaultToolkit().getImage(path);
		return img;
	}

	/**
	 * Setter for img, makes it easier to swap imgs
	 * @param img
	 */
	public void setImg(Image img) {
		this.img = img;
	}
}
