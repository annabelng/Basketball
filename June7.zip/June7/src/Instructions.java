import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;

import javax.sound.sampled.Clip;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 * Sets up the instruction page that users are taken to after clicking the "how
 * to play" button
 * 
 * @author annabelng, jaidenSmith
 *
 */
public class Instructions extends JPanel implements MouseListener, ActionListener {

	// sets up the background music
	Music music;
	Clip c;

	// sets up the different buttons
	JButton start = new JButton("Back");

	// sets up JLabel for background image
	JLabel background;
	String screen = "instructions.png";

	// initializes the size for the screen
	int screen_width = 800;
	int screen_height = 800;

	JFrame f;

	public void paint(Graphics g) {
		super.paintComponents(g);

	}

	@Override

	/**
	 * Includes the click detection for the Start and Quit Buttons
	 */
	public void actionPerformed(ActionEvent arg0) {
		// update();
		repaint();

		if (arg0.getSource() == start) {
			TitleScreen t = new TitleScreen();
			f.dispose();
		}

	}

	/**
	 * Initializes the images and objects Sets up buttons and adds images to screen
	 */
	public Instructions() {
		f = new JFrame();
		f.setTitle("Basketballers");
		f.setSize(screen_width, screen_height);
		f.getContentPane().setBackground(Color.BLACK);

		String src = new File("").getAbsolutePath() + "/src/"; // path to image setup
		ImageIcon backscreen = new ImageIcon(src + screen);

		background = new JLabel(backscreen);

		background.setBounds(0, 0, 800, 800);

		f.setResizable(false);
		f.setLayout(null);

		f.addMouseListener(this);

		music = new Music("BOUNCE+1.wav", c);

		start.setBounds(335, 565, 100, 50);
		start.addActionListener(this);

		f.add(start);

		f.add(background);
		f.add(this);

		// end creating objects
		t = new Timer(100, this);

		t.start();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
	}

	Timer t;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Instructions i = new Instructions();

	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

}